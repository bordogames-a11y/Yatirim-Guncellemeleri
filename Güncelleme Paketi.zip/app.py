import customtkinter as ctk
import sqlite3
import os
import shutil
import requests
import threading
import zipfile
from datetime import datetime
from tkinter import messagebox

DIR = r'C:\YatirimYolunda'
DB_PATH = os.path.join(DIR, 'yatirim.db')
BACKUP_PATH = os.path.join(DIR, 'yatirim_backup.db')
UPDATE_ZIP_PATH = os.path.join(DIR, 'guncelleme.zip')

# Gelecekteki v3 güncellemesi için link alanın hazır kalıyor
UPDATE_URL = 'https://github.com/KullaniciAdin/Yatirim-Guncellemeleri/raw/main/guncelleme.zip' 

def init_db():
    if not os.path.exists(DIR):
        os.makedirs(DIR)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    # Kullanıcılar tablosu
    c.execute('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT)')
    # Finansal kayıtlar tablosu
    c.execute('''CREATE TABLE IF NOT EXISTS records 
                 (id INTEGER PRIMARY KEY, user_id INTEGER, date TEXT, bugunki_para REAL, guncel_para REAL, net_kar REAL, year TEXT, month TEXT, day TEXT)''')
    conn.commit()
    conn.close()

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title('Yatırım Yolunda - Profesyonel Finans Yönetimi v2')
        self.geometry('750(' if os.name == 'nt' else '750') # Responsive genişlik
        self.geometry('750x700')
        init_db()
        
        self.current_user_id = None
        
        # Ana ekran containerı
        self.main_container = ctk.CTkFrame(self, fg_color="transparent")
        self.main_container.pack(fill="both", expand=True)
        
        # İlk olarak Giriş Ekranını Başlat
        self.show_login_screen()

    def show_login_screen(self):
        self.clear_container()
        
        login_frame = ctk.CTkFrame(self.main_container, width=350, height=400)
        login_frame.place(relx=0.5, rely=0.5, anchor="center")
        
        lbl_title = ctk.CTkLabel(login_frame, text='YAYO - Üye Girişi', font=('Arial', 20, 'bold'))
        lbl_title.pack(pady=20)
        
        self.ent_username = ctk.CTkEntry(login_frame, placeholder_text="Kullanıcı Adı", width=250)
        self.ent_username.pack(pady=10)
        
        self.ent_password = ctk.CTkEntry(login_frame, placeholder_text="Şifre", show="*", width=250)
        self.ent_password.pack(pady=10)
        
        btn_login = ctk.CTkButton(login_frame, text="Giriş Yap", command=self.login, fg_color='#2b7a0b', hover_color='#3f9e18', width=250)
        btn_login.pack(pady=10)
        
        btn_register = ctk.CTkButton(login_frame, text="Kayıt Ol", command=self.register, fg_color='#1f538d', hover_color='#2e78b8', width=250)
        btn_register.pack(pady=5)

    def login(self):
        username = self.ent_username.get()
        password = self.ent_password.get()
        
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT id FROM users WHERE username=? AND password=?", (username, password))
        user = c.fetchone()
        conn.close()
        
        if user:
            self.current_user_id = user[0]
            self.show_dashboard()
        else:
            messagebox.showerror("Hata", "Kullanıcı adı veya şifre hatalı!")

    def register(self):
        username = self.ent_username.get()
        password = self.ent_password.get()
        
        if not username or not password:
            messagebox.showwarning("Uyarı", "Lütfen alanları boş bırakmayın!")
            return
            
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (username, password) VALUES (?,?)", (username, password))
            conn.commit()
            messagebox.showinfo("Başarılı", "Hesabınız oluşturuldu! Giriş yapabilirsiniz.")
        except sqlite3.IntegrityError:
            messagebox.showerror("Hata", "Bu kullanıcı adı zaten alınmış!")
        finally:
            conn.close()

    def show_dashboard(self):
        self.clear_container()
        
        # Sekmeli Yapı (Tabview)
        self.tabview = ctk.CTkTabview(self.main_container, width=700, height=650)
        self.tabview.pack(pady=10, padx=10, fill="both", expand=True)
        
        self.tabview.add("Anasayfa & Hesaplama")
        self.tabview.add("Geçmiş Analiz (D/M/Y)")
        self.tabview.add("Sistem Güncelleme")
        
        self.setup_home_tab()
        self.setup_analysis_tab()
        self.setup_system_tab()

    def setup_home_tab(self):
        tab = self.tabview.tab("Anasayfa & Hesaplama")
        
        # 3 SÜTUNLU PANEL (Dashboard Grid)
        self.grid_frame = ctk.CTkFrame(tab, fg_color="transparent")
        self.grid_frame.pack(pady=15, fill="x")
        self.grid_frame.columnconfigure((0, 1, 2), weight=1)
        
        # Sütun 1: Bugünkü Para
        self.card1 = ctk.CTkFrame(self.grid_frame, fg_color="#1f538d", height=100)
        self.card1.grid(row=0, column=0, padx=5, sticky="nsew")
        ctk.CTkLabel(self.card1, text="Bugünkü Para (Anapara)", font=("Arial", 12, "bold"), text_color="white").pack(pady=5)
        self.lbl_bugun = ctk.CTkLabel(self.card1, text="0.00 TL", font=("Arial", 18, "bold"), text_color="white")
        self.lbl_bugun.pack(pady=5)
        
        # Sütun 2: Güncel Para
        self.card2 = ctk.CTkFrame(self.grid_frame, fg_color="#2b7a0b", height=100)
        self.grid_frame.columnconfigure(1, weight=1)
        self.card2.grid(row=0, column=1, padx=5, sticky="nsew")
        ctk.CTkLabel(self.card2, text="Güncel Para", font=("Arial", 12, "bold"), text_color="white").pack(pady=5)
        self.lbl_guncel = ctk.CTkLabel(self.card2, text="0.00 TL", font=("Arial", 18, "bold"), text_color="white")
        self.lbl_guncel.pack(pady=5)
        
        # Sütun 3: Aylık Total
        self.card3 = ctk.CTkFrame(self.grid_frame, fg_color="#e67e22", height=100)
        self.card3.grid(row=0, column=2, padx=5, sticky="nsew")
        ctk.CTkLabel(self.card3, text="Aylık Total Net Kar", font=("Arial", 12, "bold"), text_color="white").pack(pady=5)
        self.lbl_aylik_total = ctk.CTkLabel(self.card3, text="0.00 TL", font=("Arial", 18, "bold"), text_color="white")
        self.lbl_aylik_total.pack(pady=5)
        
        # NET KAR GÖSTERGESİ
        self.lbl_net_kar = ctk.CTkLabel(tab, text="Net Kar / Zarar: 0.00 TL", font=("Arial", 16, "bold"))
        self.lbl_net_kar.pack(pady=10)
        
        # VERİ GİRİŞ ALANI
        input_frame = ctk.CTkFrame(tab)
        input_frame.pack(pady=15, padx=20, fill="x")
        
        self.ent_bugun_input = ctk.CTkEntry(input_frame, placeholder_text="Bugünkü Para Girin", width=180)
        self.ent_bugun_input.grid(row=0, column=0, padx=10, pady=15)
        
        self.ent_guncel_input = ctk.CTkEntry(input_frame, placeholder_text="Güncel Para Girin", width=180)
        self.ent_guncel_input.grid(row=0, column=1, padx=10, pady=15)
        
        btn_add = ctk.CTkButton(input_frame, text="➕ Ana Para Ekle", command=self.add_financial_record, fg_color='#1f538d')
        btn_add.grid(row=0, column=2, padx=10, pady=15)
        
        self.refresh_dashboard_data()

    def setup_analysis_tab(self):
        tab = self.tabview.tab("Geçmiş Analiz (D/M/Y)")
        
        lbl_info = ctk.CTkLabel(tab, text="📊 Dönemsel Finansal Verileriniz", font=("Arial", 16, "bold"))
        lbl_info.pack(pady=10)
        
        # Analiz Metin Alanı
        self.txt_analysis = ctk.CTkTextbox(tab, width=620, height=450, font=('Consolas', 13))
        self.txt_analysis.pack(pady=10, padx=10, fill="both", expand=True)

    def setup_system_tab(self):
        tab = self.tabview.tab("Sistem Güncelleme")
        
        lbl_title = ctk.CTkLabel(tab, text="⚙️ Canlı Güncelleme Paneli", font=("Arial", 16, "bold"))
        lbl_title.pack(pady=15)
        
        self.progress = ctk.CTkProgressBar(tab, width=450)
        self.progress.pack(pady=10)
        self.progress.set(0)
        
        self.lbl_status = ctk.CTkLabel(tab, text="Sistem yeni sürüme hazır. Güncelleme beklenebilir.", font=("Arial", 12))
        self.lbl_status.pack(pady=5)
        
        self.btn_download = ctk.CTkButton(tab, text='⬇️ İnternetten Güncellemeleri Denetle ve Kur', command=self.start_download_thread, width=250)
        self.btn_download.pack(pady=10)
        
        self.btn_rollback = ctk.CTkButton(tab, text='↩️ Son Güncellemeyi Geri Al', command=self.rollback, fg_color='#b30000', hover_color='#d61a1a', width=250)
        self.btn_rollback.pack(pady=10)

    def add_financial_record(self):
        try:
            b_para = float(self.ent_bugun_input.get())
            g_para = float(self.ent_guncel_input.get())
        except ValueError:
            messagebox.showwarning("Hata", "Lütfen geçerli sayısal değerler girin!")
            return
            
        net_kar = g_para - b_para
        now = datetime.now()
        date_str = now.strftime("%Y-%m-%d %H:%M:%S")
        year = now.strftime("%Y")
        month = now.strftime("%m")
        day = now.strftime("%d")
        
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("INSERT INTO records (user_id, date, bugunki_para, guncel_para, net_kar, year, month, day) VALUES (?,?,?,?,?,?,?,?)",
                  (self.current_user_id, date_str, b_para, g_para, net_kar, year, month, day))
        conn.commit()
        conn.close()
        
        messagebox.showinfo("Başarılı", "Verileriniz başarıyla işlendi ve 3. sütuna (arşive) aktarıldı!")
        self.ent_bugun_input.delete(0, 'end')
        self.ent_guncel_input.delete(0, 'end')
        
        self.refresh_dashboard_data()
        self.refresh_analysis_data()

    def refresh_dashboard_data(self):
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        
        # En son kaydı çekerek kartları güncelle
        c.execute("SELECT bugunki_para, guncel_para, net_kar FROM records WHERE user_id=? ORDER BY id DESC LIMIT 1", (self.current_user_id,))
        last_row = c.fetchone()
        
        if last_row:
            self.lbl_bugun.configure(text=f"{last_row[0]:,.2f} TL")
            self.lbl_guncel.configure(text=f"{last_row[1]:,.2f} TL")
            
            kar_color = "#2b7a0b" if last_row[2] >= 0 else "#b30000"
            self.lbl_net_kar.configure(text=f"Son İşlem Net Kar / Zarar: {last_row[2]:,.2f} TL", text_color=kar_color)
        
        # Bu ayın toplam net karını hesapla
        current_month = datetime.now().strftime("%m")
        current_year = datetime.now().strftime("%Y")
        c.execute("SELECT SUM(net_kar) FROM records WHERE user_id=? AND month=? AND year=?", (self.current_user_id, current_month, current_year))
        monthly_sum = c.fetchone()[0]
        
        if monthly_sum:
            self.lbl_aylik_total.configure(text=f"{monthly_sum:,.2f} TL")
        else:
            self.lbl_aylik_total.configure(text="0.00 TL")
            
        conn.close()

    def refresh_analysis_data(self):
        self.txt_analysis.delete('1.0', 'end')
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        
        self.txt_analysis.insert('end', "=== 📆 GÜNLÜK VERİ GEÇMİŞİ ===\n")
        c.execute("SELECT date, bugunki_para, guncel_para, net_kar FROM records WHERE user_id=? ORDER BY id DESC", (self.current_user_id,))
        for r in c.fetchall():
            self.txt_analysis.insert('end', f"Tarih: {r[0]} | Başlangıç: {r[1]} TL | Güncel: {r[2]} TL | Kar: {r[3]} TL\n")
            
        self.txt_analysis.insert('end', "\n=== 🗓️ AYLIK ÖZET RAPORU ===\n")
        c.execute("SELECT year, month, SUM(net_kar) FROM records WHERE user_id=? GROUP BY year, month ORDER BY year DESC, month DESC", (self.current_user_id,))
        for r in c.fetchall():
            self.txt_analysis.insert('end', f"Dönem: {r[1]}/{r[0]} -> Toplam Net Kar: {r[2]} TL\n")
            
        self.txt_analysis.insert('end', "\n=== 📊 YILLIK ÖZET RAPORU ===\n")
        c.execute("SELECT year, SUM(net_kar) FROM records WHERE user_id=? GROUP BY year ORDER BY year DESC", (self.current_user_id,))
        for r in c.fetchall():
            self.txt_analysis.insert('end', f"Yıl: {r[0]} -> Toplam Net Kar: {r[1]} TL\n")
            
        conn.close()

    def start_download_thread(self):
        self.btn_download.configure(state='disabled')
        threading.Thread(target=self.download_and_install_update, daemon=True).start()

    def download_and_install_update(self):
        try:
            self.after(0, self.update_status, 'Mevcut veritabanı yedekleniyor...', 0.2)
            if os.path.exists(DB_PATH):
                shutil.copyfile(DB_PATH, BACKUP_PATH)

            response = requests.get(UPDATE_URL, stream=True, timeout=12)
            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            block_size = 8192
            downloaded_size = 0

            with open(UPDATE_ZIP_PATH, 'wb') as file:
                for data in response.iter_content(block_size):
                    file.write(data)
                    downloaded_size += len(data)
                    if total_size > 0:
                        self.after(0, self.update_status, f'İndiriliyor: {downloaded_size/(1024*1024):.1f} MB / {total_size/(1024*1024):.1f} MB', downloaded_size / total_size)

            self.after(0, self.update_status, 'Paket açılıyor ve entegre ediliyor...', 0.9)
            with zipfile.ZipFile(UPDATE_ZIP_PATH, 'r') as zip_ref:
                zip_ref.extractall(DIR)
            
            os.remove(UPDATE_ZIP_PATH)
            self.after(0, self.update_status, 'Sistem başarıyla güncellendi!', 1.0)
            self.after(0, lambda: messagebox.showinfo('Başarılı', 'Uygulama başarıyla güncellendi! Lütfen uygulamayı yeniden başlatın.'))
        except Exception as e:
            self.after(0, self.update_status, 'Hata oluştu!', 0)
            self.after(0, lambda: messagebox.showerror('Hata', f'İndirme başarısız:\n{e}'))
        finally:
            self.after(0, lambda: self.btn_download.configure(state='normal'))

    def update_status(self, text, val):
        self.lbl_status.configure(text=text)
        self.progress.set(val)

    def rollback(self):
        if os.path.exists(BACKUP_PATH):
            shutil.copyfile(BACKUP_PATH, DB_PATH)
            messagebox.showinfo('Kurtarma Başarılı', 'Güncelleme başarıyla geri alındı, eski verileriniz yüklendi!')
            if self.current_user_id:
                self.refresh_dashboard_data()
        else:
            messagebox.showwarning('Hata', 'Geri alınacak veri yedeği bulunamadı.')

    def clear_container(self):
        for widget in self.main_container.winfo_children():
            widget.destroy()

if __name__ == '__main__':
    app = App()
    app.mainloop()