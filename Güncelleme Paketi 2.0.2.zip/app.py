import customtkinter as ctk
import sqlite3
import os
import shutil
import requests
import threading
import zipfile
from datetime import datetime
from tkinter import messagebox

DIR = r'C:\YatirimYolunda'
DB_PATH = os.path.join(DIR, 'yatirim.db')
BACKUP_PATH = os.path.join(DIR, 'yatirim_backup.db')
UPDATE_ZIP_PATH = os.path.join(DIR, 'guncelleme.zip')
UPDATE_URL = 'https://github.com/KullaniciAdin/Yatirim-Guncellemeleri/raw/main/guncelleme.zip' 

def init_db():
    if not os.path.exists(DIR): os.makedirs(DIR)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT)')
    c.execute('''CREATE TABLE IF NOT EXISTS records (id INTEGER PRIMARY KEY, user_id INTEGER, date TEXT, bugunki_para REAL, guncel_para REAL, net_kar REAL, year TEXT, month TEXT, day TEXT)''')
    conn.commit()
    conn.close()

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title('Yatırım Yolunda - Profesyonel Finans Yönetimi v2')
        self.geometry('750x750')
        init_db()
        self.current_user_id = None
        self.main_container = ctk.CTkFrame(self, fg_color="transparent")
        self.main_container.pack(fill="both", expand=True)
        self.show_login_screen()

    def show_login_screen(self):
        self.clear_container()
        login_frame = ctk.CTkFrame(self.main_container, width=350, height=400)
        login_frame.place(relx=0.5, rely=0.5, anchor="center")
        ctk.CTkLabel(login_frame, text='Finans Yönetim', font=('Arial', 20, 'bold')).pack(pady=20)
        self.ent_username = ctk.CTkEntry(login_frame, placeholder_text="Kullanıcı Adı", width=250)
        self.ent_username.pack(pady=10)
        self.ent_password = ctk.CTkEntry(login_frame, placeholder_text="Şifre", show="*", width=250)
        self.ent_password.pack(pady=10)
        ctk.CTkButton(login_frame, text="Giriş Yap", command=self.login, fg_color='#2b7a0b', width=250).pack(pady=10)
        ctk.CTkButton(login_frame, text="Kayıt Ol", command=self.register, fg_color='#1f538d', width=250).pack(pady=5)

    def login(self):
        username = self.ent_username.get()
        password = self.ent_password.get()
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT id FROM users WHERE username=? AND password=?", (username, password))
        user = c.fetchone()
        conn.close()
        if user:
            self.current_user_id = user[0]
            self.show_dashboard()
        else: messagebox.showerror("Hata", "Kullanıcı adı veya şifre hatalı!")

    def register(self):
        username = self.ent_username.get()
        password = self.ent_password.get()
        if not username or not password: return
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (username, password) VALUES (?,?)", (username, password))
            conn.commit()
            messagebox.showinfo("Başarılı", "Hesabınız oluşturuldu!")
        except: messagebox.showerror("Hata", "Bu kullanıcı adı zaten alınmış!")
        finally: conn.close()

    def show_dashboard(self):
        self.clear_container()
        self.tabview = ctk.CTkTabview(self.main_container, width=700, height=700)
        self.tabview.pack(pady=10, padx=10, fill="both", expand=True)
        self.tabview.add("Anasayfa & Hesaplama")
        self.tabview.add("Geçmiş Analiz (D/M/Y)")
        self.tabview.add("Ayarlar") 
        self.setup_home_tab()
        self.setup_analysis_tab()
        self.setup_settings_tab()

    def setup_home_tab(self):
        tab = self.tabview.tab("Anasayfa & Hesaplama")
        
        # 1. GÖRSELDEKİ ÜÇLÜ KART YAPISI
        card_frame = ctk.CTkFrame(tab, fg_color="transparent")
        card_frame.pack(pady=10, fill="x")
        
        # Her bir kart için kolon ağırlığı
        card_frame.columnconfigure((0, 1, 2), weight=1)
        
        # Kart 1: Anapara
        self.card_ana = ctk.CTkFrame(card_frame, fg_color="#1f538d", height=80)
        self.card_ana.grid(row=0, column=0, padx=5, sticky="nsew")
        ctk.CTkLabel(self.card_ana, text="Bugünkü Para (Anapara)", font=("Arial", 12)).pack(pady=(5,0))
        self.lbl_ana = ctk.CTkLabel(self.card_ana, text="0.00 TL", font=("Arial", 18, "bold"))
        self.lbl_ana.pack(pady=5)
        
        # Kart 2: Güncel
        self.card_gun = ctk.CTkFrame(card_frame, fg_color="#2b7a0b", height=80)
        self.card_gun.grid(row=0, column=1, padx=5, sticky="nsew")
        ctk.CTkLabel(self.card_gun, text="Güncel Para", font=("Arial", 12)).pack(pady=(5,0))
        self.lbl_gun = ctk.CTkLabel(self.card_gun, text="0.00 TL", font=("Arial", 18, "bold"))
        self.lbl_gun.pack(pady=5)
        
        # Kart 3: Aylık Toplam (Görseldeki 3. kart)
        self.card_toplam = ctk.CTkFrame(card_frame, fg_color="#e67e22", height=80)
        self.card_toplam.grid(row=0, column=2, padx=5, sticky="nsew")
        ctk.CTkLabel(self.card_toplam, text="Aylık Total Net Kar", font=("Arial", 12)).pack(pady=(5,0))
        self.lbl_total_k_z = ctk.CTkLabel(self.card_toplam, text="0.00 TL", font=("Arial", 18, "bold"))
        self.lbl_total_k_z.pack(pady=5)

        # Son İşlem Etiketi
        self.lbl_son_islem = ctk.CTkLabel(tab, text="Son İşlem Net Kar / Zarar: 0.00 TL", font=("Arial", 14, "bold"))
        self.lbl_son_islem.pack(pady=10)

        # 2. GİRİŞ ALANI
        input_frame = ctk.CTkFrame(tab, fg_color="transparent")
        input_frame.pack(pady=10, fill="x")
        self.ent_bugun_input = ctk.CTkEntry(input_frame, placeholder_text="Bugünkü Para Girin")
        self.ent_bugun_input.pack(side="left", expand=True, fill="x", padx=5)
        self.ent_guncel_input = ctk.CTkEntry(input_frame, placeholder_text="Güncel Para Girin")
        self.ent_guncel_input.pack(side="left", expand=True, fill="x", padx=5)
        ctk.CTkButton(input_frame, text="➕ Ana Para Ekle", command=self.add_financial_record).pack(side="left", padx=5)

        # 3. LİSTE (Alt kısım)
        self.scroll_list = ctk.CTkScrollableFrame(tab, label_text="Geçmiş Kayıtlar", height=200)
        self.scroll_list.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.refresh_dashboard_data()

    def delete_record(self, record_id):
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("DELETE FROM records WHERE id=?", (record_id,))
        conn.commit()
        conn.close()
        self.refresh_dashboard_data()
        self.refresh_analysis_data()

    def refresh_dashboard_data(self):
        for widget in self.scroll_list.winfo_children(): widget.destroy()
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        
        # Son kayıtları çek
        c.execute("SELECT id, date, bugunki_para, guncel_para, net_kar FROM records WHERE user_id=? ORDER BY id DESC LIMIT 30", (self.current_user_id,))
        records = c.fetchall()
        
        if records:
            # En son kaydı kartlara bas
            latest = records[0]
            self.lbl_ana.configure(text=f"{latest[2]:,.2f} TL")
            self.lbl_gun.configure(text=f"{latest[3]:,.2f} TL")
            self.lbl_son_islem.configure(text=f"Son İşlem Net Kar / Zarar: {latest[4]:,.2f} TL")
            
            # Kart listesini oluştur
            for r in records:
                row = ctk.CTkFrame(self.scroll_list, fg_color="transparent")
                row.pack(fill="x", pady=2)
                color = "#2b7a0b" if r[4] >= 0 else "#b30000"
                ctk.CTkLabel(row, text=f"{r[1]} | Kar: {r[4]:,.2f} TL", text_color=color).pack(side="left", padx=5)
                ctk.CTkButton(row, text="SİL", width=40, fg_color="#b30000", command=lambda rid=r[0]: self.delete_record(rid)).pack(side="right")
        
        # Genel toplamı hesapla
        c.execute("SELECT SUM(net_kar) FROM records WHERE user_id=?", (self.current_user_id,))
        total = c.fetchone()[0] or 0.0
        self.lbl_total_k_z.configure(text=f"{total:,.2f} TL")
        conn.close()

    def setup_analysis_tab(self):
        tab = self.tabview.tab("Geçmiş Analiz (D/M/Y)")
        # MODERN LUXURY LİSTE GÖRÜNÜMÜ (Textbox yerine liste yapısı)
        self.analysis_list = ctk.CTkScrollableFrame(tab, fg_color="transparent")
        self.analysis_list.pack(fill="both", expand=True, padx=10, pady=10)
        self.refresh_analysis_data()

    def refresh_analysis_data(self):
        for widget in self.analysis_list.winfo_children(): widget.destroy()
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT date, bugunki_para, guncel_para, net_kar FROM records WHERE user_id=? ORDER BY id DESC", (self.current_user_id,))
        for r in c.fetchall():
            card = ctk.CTkFrame(self.analysis_list, fg_color="#2b2b2b", corner_radius=10)
            card.pack(fill="x", pady=5, padx=5)
            color = "#2b7a0b" if r[3] >= 0 else "#b30000"
            ctk.CTkLabel(card, text=f"📅 {r[0]}", font=("Arial", 12)).pack(side="left", padx=10)
            ctk.CTkLabel(card, text=f"💰 {r[3]:,.2f} TL", font=("Arial", 14, "bold"), text_color=color).pack(side="right", padx=10)
        conn.close()

    # (Diğer fonksiyonlar orijinal yapınla aynı kalmıştır)
    def setup_settings_tab(self):
        tab = self.tabview.tab("Ayarlar")
        self.theme_switch = ctk.CTkSwitch(tab, text="Karanlık Mod", command=self.change_theme)
        self.theme_switch.pack(pady=20)
        self.lbl_status = ctk.CTkLabel(tab, text="Sürüm: v2.0.1 (Güncel)")
        self.lbl_status.pack()
        ctk.CTkButton(tab, text='⬇️ Güncellemeleri Denetle', command=lambda: messagebox.showinfo("Bilgi", "Sistem güncel.")).pack(pady=5)

    def change_theme(self): ctk.set_appearance_mode("Dark" if self.theme_switch.get() == 1 else "Light")
    def clear_container(self): 
        for widget in self.main_container.winfo_children(): widget.destroy()
    def add_financial_record(self):
        try:
            b_para = float(self.ent_bugun_input.get())
            g_para = float(self.ent_guncel_input.get())
            net_kar = g_para - b_para
            now = datetime.now()
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("INSERT INTO records (user_id, date, bugunki_para, guncel_para, net_kar, year, month, day) VALUES (?,?,?,?,?,?,?,?)",
                      (self.current_user_id, now.strftime("%d.%m.%Y %H:%M:%S"), b_para, g_para, net_kar, now.strftime("%Y"), now.strftime("%m"), now.strftime("%d")))
            conn.commit()
            conn.close()
            self.refresh_dashboard_data()
            self.refresh_analysis_data()
        except: messagebox.showwarning("Hata", "Lütfen sayısal değer giriniz.")

if __name__ == '__main__':
    app = App()
    app.mainloop()